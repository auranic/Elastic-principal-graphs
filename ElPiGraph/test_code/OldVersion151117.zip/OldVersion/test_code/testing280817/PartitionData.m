
function [partition, dists] = ...
    PartitionData(X, NodePositions, MaxBlockSize, SquaredX, TrimmingRadius)
%%%%%%%%%%%%%%%%%%%%%%%
%% Partition the data by proximity to graph nodes (same step as in K-means EM procedure)
%%%%%%%%%%%%%%%%%%%%%%%
%
%Inputs:
%   X is n-by-m matrix of datapints with one data point per row. n is
%       number of data points and m is dimension of data space.
%   NodePositions is k-by-m matrix of embedded coordinates of graph nodes,
%       where k is number of nodes and m is dimension of data space.
%   MaxBlockSize integer number which defines maximal number of
%       simultaneously calculated distances. Maximal size of created matrix
%       is MaxBlockSize-by-k, where k is number of nodes.
%   SquaredX is n-by-1 vector of data vectors length: SquaredX = sum(X.^2,2); 
%
%   partition is n-by-1 vector. partition(i) is number of node which is
%       associated with data point X(i,:).
%

    if nargin<5
        TrimmingRadius = Inf;
    end
    n = size(X, 1);
    partition = zeros(n, 1);
    dists = zeros(n, 1);
    %Calculate squared length of centroids
    cent = NodePositions';
    centrLength = sum(cent.^2);
    %Process partitioning without trimming
    for i = 1:MaxBlockSize:n
        % Define last element for calculation
        last = i + MaxBlockSize - 1;
        if last > n
            last = n;
        end
        % Prepare index
        ind = i:last;
        % Calculate distances
        d = bsxfun(@plus, SquaredX(ind), centrLength) - 2 * (X(ind,:) * cent);
        [dists(ind), partition(ind)] = min(d,[],2);
    end
    %Apply trimming
    ind = dists > TrimmingRadius;
    partition(ind) = 0;
    dists(ind) = TrimmingRadius^2;
end